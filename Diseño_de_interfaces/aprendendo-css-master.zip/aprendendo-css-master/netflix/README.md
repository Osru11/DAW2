# Logo Netflix

- HTML
- CSS

## Preview

<div align="center">
  <img src="preview.png" alt="Logo Netflix">
</div>

## 🔗 [Tutorial](https://youtu.be/Jwrk1PZHZrI)

<div style="width: 70%; margin: 0 auto">
  <a href="https://youtu.be/FNA_rG-R598" title="Tutorial">
    <img align="center" src="youtube.jpg" alt="Youtube video">
  </a>
</div>