# Recriando imagem do aplicativo Duolingo com CSS (Menino, macaco e elefante)

## Linguagens e tecnologias
* SCSS
* JS
___ 
O diferencial desse desenho é a animação (feita com manipulação do DOM) que faz parecer que o menino segue o cursor do mouse com o olhar. O código pode melhorar bastante, principalmente neste ponto da animação, mas deixei como algo a ser alterado futuramente.

## Preview

<div align="center">
    <img src="preview-duo.gif" alt="GIF animado mostrando o resultado">
</div>

<p align="center">
    (Na esquerda, minha versão da imagem, feita com HTML, CSS e JS. Na direita, a imagem original)
</p>