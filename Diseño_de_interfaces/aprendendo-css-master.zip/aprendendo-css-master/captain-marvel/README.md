# Símbolo da Capitã Marvel

- HTML
- CSS

## 🔗 [Speed code (Timelapse)](https://youtu.be/-vzY2ys7f0Q)

<div style="width: 60%; margin: 0 auto">
  <a href="https://youtu.be/-vzY2ys7f0Q" title="Timelapse">
    <img align="center" src="youtube.jpg" alt="Youtube video">
  </a>
</div>

## Preview

<div align="center">
  <img src="preview.png" alt="Captain Marvel symbol">
</div>