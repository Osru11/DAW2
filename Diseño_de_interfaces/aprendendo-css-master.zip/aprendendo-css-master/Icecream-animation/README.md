# Ice cream animation
Código feito com base no vídeo disponível [aqui](https://youtu.be/wziBSI-8Dng?list=WL).
___
## Preview
<p align="center">
    <img src="preview.gif" alt="Preview">
</p>