# Pixel-art do tripulante do jogo Among Us

Pixel-art com SCSS, sem uso de SVG's ou imagens externas. 
## Linguagens e tecnologias
* HTML5
* SCSS
* [Particles.js](https://github.com/VincentGarreau/particles.js/)
___ 
## Preview

<div align="center">
    <img src="amongus-preview.gif" alt="GIF animado mostrando o resultado">
</div>