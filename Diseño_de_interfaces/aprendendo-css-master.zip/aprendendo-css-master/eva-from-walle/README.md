# Personagem Eva do filme Wall-e


## Tecnologias e ferramentas

- HTML
- SCSS
- Figma

## Sites que ajudaram demais
- [Fancy Border-Radius](https://9elements.github.io/fancy-border-radius/full-control.html)
- [Stripes in CSS (CSS-Tricks)](https://css-tricks.com/stripes-css/)

## Preview
<div>
    <img src="eva-preview.png" alt="Eva">
</div>