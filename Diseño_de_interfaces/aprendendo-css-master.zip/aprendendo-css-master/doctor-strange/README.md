# Doctor Strange (Doutor Estranho) Logo - CSS

- CSS
  - overflow: hidden
  - keyframes
  - drop-shadow

## Preview

<div align="center">
  <img src="preview.gif" alt="Logo Netflix">
</div>

## 🎬 [Speedcode (Youtube)](https://youtu.be/u7XK-aRL1MU)

<div style="width: 70%; margin: 0 auto">
  <a href="https://youtu.be/u7XK-aRL1MU" title="Link for speedcode video">
    <img align="center" src="speedcode.jpg" alt="Thumbnail">
  </a>
</div>