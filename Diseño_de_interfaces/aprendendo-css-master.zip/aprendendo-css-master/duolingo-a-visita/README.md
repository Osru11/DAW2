# Personagem do Duolingo


## Preview
<div align="center">
    <img src="a-visita-duo.png" alt="Preview do desenho">
</div>

<p align="center">
    (Na esquerda, a imagem original do site do Duolingo. Na direita, minha versão, com SCSS e HTML)
</p>