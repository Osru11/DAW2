# Uchiha

- HTML
- CSS

## Speedcode (Vídeo)
<div style="width: 75%; margin: 0 auto">
  <a href="https://www.youtube.com/watch?v=TV9iMqMi1C4" title="Speedcode" target="_blank">
    <img src="speedcode.jpg" alt="video thumbnail">
  </a>
</div>


## Preview

<div align="center">
  <img src="preview.png" alt="Símbolo do clã Uchiha, nas cores vermelho e branco">
</div>