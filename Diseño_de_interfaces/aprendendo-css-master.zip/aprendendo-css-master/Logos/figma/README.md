# Logo do Figma

## Linguagens e tecnologias
* HTML
* CSS

## Preview

<div align="center">
    <img src="preview-figma.png" alt="Preview">
</div>