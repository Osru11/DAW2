# Android

- HTML
- CSS
- Emmet Abbreviations

## Speed code (Timelapse)
<div style="width: 75%; margin: 0 auto">
  <a href="https://www.linkedin.com/feed/update/urn:li:activity:6887443944238563328/" title="Timelapse" target="_blank">
    <img src="speedcode.png" alt="video thumbnail">
  </a>
</div>


## Preview

<div align="center">
  <img src="preview.png" alt="Preview da arte">
</div>