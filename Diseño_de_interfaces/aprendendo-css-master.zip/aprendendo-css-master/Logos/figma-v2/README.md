# Figma logo

- HTML
- CSS

## Preview

<div align="center">
  <img src="preview.png" alt="logo preview">
</div>