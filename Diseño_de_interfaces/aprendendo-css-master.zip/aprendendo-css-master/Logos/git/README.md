# Logo do Git

Não está perfeito, mas foi legal codar 😅

## Linguagens e tecnologias
* HTML
* CSS

## Preview

<div align="center">
    <img src="preview-git-logo.png" alt="Preview">
    <p>Original / Versão em CSS</p>
</div>