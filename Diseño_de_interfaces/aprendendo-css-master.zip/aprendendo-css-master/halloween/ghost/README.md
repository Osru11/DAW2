# Fantasma (CSS Only)

### Acessar
No live preview, o desenho contém animações 🤙

[Ver a renderização do código diretamente no navegador / Live preview](https://natalia-fs.github.io/aprendendo-css/halloween/ghost/)

## Preview
<div>
  <img src="preview.png" alt="Fantasma minimalista, com sorriso no rosto e olhos brilhantes">
</div>