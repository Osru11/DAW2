# Âncora
Esse desenho foi inspirado no ícone de âncora do FontAwesome, que pode ser encontrado [aqui](https://fontawesome.com/v5.15/icons/anchor)
## Preview
<p align="center">
    <img src="preview.jpg" alt="Preview">
</p>
