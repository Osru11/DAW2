# Câmera

- HTML
- CSS
- Figma

## Preview

<p align="center">
    <img src="retro-camera.png" alt="Preview">
</p>

## 🔗 [Câmera 📷 (HTML + CSS) | CSS Speed Art | Timelapse](https://youtu.be/OcXCPXHuw6s)

<div>
  <a href="https://youtu.be/OcXCPXHuw6s" title="Timelapse">
    <img src="thumb.jpg" alt="Youtube video">
  </a>
</div>