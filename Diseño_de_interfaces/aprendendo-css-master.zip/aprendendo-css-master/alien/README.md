# Alien (CSS Only)

## Acessar

[Ver a renderização do código diretamente no navegador](https://natalia-fs.github.io/aprendendo-css/alien/)

## Preview
<div>
  <img src="preview.png" alt="Alien">
</div>