# Símbolo da Viúva Negra

- HTML
- CSS

## Preview

<div align="center">
  <img src="preview.png" alt="Black widow symbol">
</div>