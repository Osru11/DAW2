# Lin (CSS Only)

## Acessar

[Ver a renderização do código diretamente no navegador / Live preview](https://natalia-fs.github.io/aprendendo-css/duolingo/lin/)

## Preview
<div>
  <img src="preview.png" alt="Lin, personagem do app Duolingo">
</div>