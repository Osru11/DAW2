# Duolingo's Art Style - Car

- HTML
- CSS

## Preview

<p align="center">
    <img src="preview.png" alt="Preview">
</p>
