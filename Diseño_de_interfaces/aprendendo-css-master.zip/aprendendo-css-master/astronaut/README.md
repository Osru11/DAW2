# Astronaut

## 🔗 [Speed code (Timelapse)](https://youtu.be/NyGw18D83tk)

<div style="width: 60%; margin: 0 auto">
  <a href="https://youtu.be/NyGw18D83tk" title="Timelapse">
    <img align="center" src="youtube.jpg" alt="Youtube video">
  </a>
</div>

## Preview

<div align="center">
  <img src="astronaut.png" alt="Preview da arte">
</div>
