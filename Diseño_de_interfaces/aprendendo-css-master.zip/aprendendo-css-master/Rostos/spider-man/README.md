# Spider-man mask (CSS Only)

## Acessar

[Ver a renderização do código diretamente no navegador / Live preview](https://natalia-fs.github.io/aprendendo-css/Rostos/spider-man/)

## Preview
<div>
  <img src="preview.JPG" alt="Spider-man mask / Máscara do Homem-aranha">
</div>