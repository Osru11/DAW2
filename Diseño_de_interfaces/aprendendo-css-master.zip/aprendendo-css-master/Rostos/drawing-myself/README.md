# Me desenhando em estilo Flat Art com CSS

Me inspirei nas artes do [Mark Rise](https://www.youtube.com/channel/UCX4mqbvv5lGqLpI4FYlJt4w), mais especificamente neste vídeo [aqui](https://youtu.be/v-nSIPzE2Mk).

Usei HTML5, SCSS e criatividade 😅

## Preview

<div align="center">
    <img src="preview-drawing-myself.png" alt="Desenho">
</div>