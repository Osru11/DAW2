# Escudo do Capitão América

- HTML
- CSS

## 🔗 [Speed code (Timelapse)](https://youtu.be/FNA_rG-R598)

<div style="width: 60%; margin: 0 auto">
  <a href="https://youtu.be/FNA_rG-R598" title="Timelapse">
    <img align="center" src="youtube.jpg" alt="Youtube video">
  </a>
</div>

## Preview

<div align="center">
  <img src="shield.png" alt="Shield">
</div>