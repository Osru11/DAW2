# Desenhando um robô estilo emoji

## Tecnologias e ferramentas
- CSS
- HTML
- Figma

## Preview

<div align="center">
    <img src="preview-robot.png" alt="Robô" />
    <p>Esquerda: arte feita no Figma (com base nos emojis). Direita: arte em CSS</p>
</div>