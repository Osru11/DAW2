# Steven Universe Minimalista
Desenhei o personagem Steven Universe estilizando divs com SCSS.
## Linguagens e tecnologias
* HTML
* SCSS
## Preview

<p align="center">
(Arte original / Versão em SCSS)
</p>

<div align="center">
    <img src="preview-steven.png" alt="Steven Universe">
</div>

<p align="center">
(A arte original não me pertence, as informações do autor se encontram no screenshot)
</p>