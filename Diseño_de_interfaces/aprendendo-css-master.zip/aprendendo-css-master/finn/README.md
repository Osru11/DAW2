# Finn (CSS Only)

## Acessar

[Ver a renderização do código diretamente no navegador / Live preview](https://natalia-fs.github.io/aprendendo-css/finn/)

## Preview
<div>
  <img src="preview.png" alt="Finn, personagem da série Hora de aventura">
</div>