# Pokebola

Código simples com SCSS

## Preview

<div align="center">
    <img src="preview-pokeball.png" alt="Preview">
    <p>(Esquerda: imagem original; Direita: versão em Scss)</p>
</div>